const quiz = require('./candidate-testing');

quiz.runProgram();